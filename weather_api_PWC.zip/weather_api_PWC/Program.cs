﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace weather_api_PWC
{
    class Program
    {
        static void Main(string[] args)
        {
            mainmethod();
        }

        public static void mainmethod()
        {
            string city = getinput();
            (string lat, string lon) = GetLatLong(city);

           
            if(lat == null || lon ==null)
            {
                Console.WriteLine("unable to find lat long");
                mainmethod();
            }
            else
            {
                weaterReport(lat, lon);
              
                mainmethod();
            }
           
        }
        public static string getinput()
        {
            string city;
            Console.Write("Enter City: ");
            city = Console.ReadLine();
            return city;
        }

        public static (string lat,string lon) GetLatLong (string city)
        {
            string dbPath = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location) + "\\Database1.mdf";
            string strConnection =
                @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename="+ dbPath +";Integrated Security=True";
            string lat = null;
            string lon = null;
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection(strConnection);
            conn.Open();

            SqlCommand command = new SqlCommand("Select * from [MASTER_LAT_LONG] where CITY=@city", conn);
            command.Parameters.AddWithValue("@city", city.ToUpper());
            SqlDataAdapter adapter = new SqlDataAdapter(command);

            adapter.Fill(dt);
            if(dt.Rows.Count>0)
            {
                for(int i=0;i<dt.Rows.Count;i++ )
                {
                    lat = dt.Rows[i]["LAT"].ToString();

                    lon = dt.Rows[i]["LONG"].ToString();
                }    
                
            }
           

            conn.Close();
            return (lat, lon);
        }

        public static void weaterReport(string lat,string lon)
        {
            try
            {
                WebRequest request = HttpWebRequest.Create("https://api.open-meteo.com/v1/forecast?latitude=" + lat + "&longitude=" + lon + "&current_weather=true");
                WebResponse response = request.GetResponse();
                StreamReader reader = new StreamReader(response.GetResponseStream());
                string urlText = reader.ReadToEnd();
                dynamic json = JObject.Parse(urlText);
                dynamic jsonweather = json.current_weather;
                string temp = jsonweather.temperature;
                Console.WriteLine("Temperature : {0}", jsonweather.temperature.ToString());
                Console.WriteLine("Windspeed : {0}", jsonweather.windspeed.ToString());
                Console.WriteLine("Winddirection : {0}", jsonweather.winddirection.ToString());
                Console.WriteLine("Time : {0}", jsonweather.weathercode.ToString());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());    
                mainmethod();
            }
        }
    }
    }

